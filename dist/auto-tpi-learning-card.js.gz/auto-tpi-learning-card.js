/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t=globalThis,e=t.ShadowRoot&&(void 0===t.ShadyCSS||t.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,i=Symbol(),s=new WeakMap;let o=class{constructor(t,e,s){if(this._$cssResult$=!0,s!==i)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const i=this.t;if(e&&void 0===t){const e=void 0!==i&&1===i.length;e&&(t=s.get(i)),void 0===t&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),e&&s.set(i,t))}return t}toString(){return this.cssText}};const n=(t,...e)=>{const s=1===t.length?t[0]:e.reduce((e,i,s)=>e+(t=>{if(!0===t._$cssResult$)return t.cssText;if("number"==typeof t)return t;throw Error("Value passed to 'css' function must be a 'css' function result: "+t+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+t[s+1],t[0]);return new o(s,t,i)},a=e?t=>t:t=>t instanceof CSSStyleSheet?(t=>{let e="";for(const i of t.cssRules)e+=i.cssText;return(t=>new o("string"==typeof t?t:t+"",void 0,i))(e)})(t):t,{is:r,defineProperty:l,getOwnPropertyDescriptor:h,getOwnPropertyNames:c,getOwnPropertySymbols:d,getPrototypeOf:p}=Object,_=globalThis,u=_.trustedTypes,g=u?u.emptyScript:"",f=_.reactiveElementPolyfillSupport,m=(t,e)=>t,y={toAttribute(t,e){switch(e){case Boolean:t=t?g:null;break;case Object:case Array:t=null==t?t:JSON.stringify(t)}return t},fromAttribute(t,e){let i=t;switch(e){case Boolean:i=null!==t;break;case Number:i=null===t?null:Number(t);break;case Object:case Array:try{i=JSON.parse(t)}catch(t){i=null}}return i}},x=(t,e)=>!r(t,e),v={attribute:!0,type:String,converter:y,reflect:!1,useDefault:!1,hasChanged:x};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */Symbol.metadata??=Symbol("metadata"),_.litPropertyMetadata??=new WeakMap;let $=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=v){if(e.state&&(e.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(t)&&((e=Object.create(e)).wrapped=!0),this.elementProperties.set(t,e),!e.noAccessor){const i=Symbol(),s=this.getPropertyDescriptor(t,i,e);void 0!==s&&l(this.prototype,t,s)}}static getPropertyDescriptor(t,e,i){const{get:s,set:o}=h(this.prototype,t)??{get(){return this[e]},set(t){this[e]=t}};return{get:s,set(e){const n=s?.call(this);o?.call(this,e),this.requestUpdate(t,n,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??v}static _$Ei(){if(this.hasOwnProperty(m("elementProperties")))return;const t=p(this);t.finalize(),void 0!==t.l&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty(m("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(m("properties"))){const t=this.properties,e=[...c(t),...d(t)];for(const i of e)this.createProperty(i,t[i])}const t=this[Symbol.metadata];if(null!==t){const e=litPropertyMetadata.get(t);if(void 0!==e)for(const[t,i]of e)this.elementProperties.set(t,i)}this._$Eh=new Map;for(const[t,e]of this.elementProperties){const i=this._$Eu(t,e);void 0!==i&&this._$Eh.set(i,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const i=new Set(t.flat(1/0).reverse());for(const t of i)e.unshift(a(t))}else void 0!==t&&e.push(a(t));return e}static _$Eu(t,e){const i=e.attribute;return!1===i?void 0:"string"==typeof i?i:"string"==typeof t?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(t=>t(this))}addController(t){(this._$EO??=new Set).add(t),void 0!==this.renderRoot&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){const t=new Map,e=this.constructor.elementProperties;for(const i of e.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const i=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return((i,s)=>{if(e)i.adoptedStyleSheets=s.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(const e of s){const s=document.createElement("style"),o=t.litNonce;void 0!==o&&s.setAttribute("nonce",o),s.textContent=e.cssText,i.appendChild(s)}})(i,this.constructor.elementStyles),i}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(t=>t.hostConnected?.())}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach(t=>t.hostDisconnected?.())}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$ET(t,e){const i=this.constructor.elementProperties.get(t),s=this.constructor._$Eu(t,i);if(void 0!==s&&!0===i.reflect){const o=(void 0!==i.converter?.toAttribute?i.converter:y).toAttribute(e,i.type);this._$Em=t,null==o?this.removeAttribute(s):this.setAttribute(s,o),this._$Em=null}}_$AK(t,e){const i=this.constructor,s=i._$Eh.get(t);if(void 0!==s&&this._$Em!==s){const t=i.getPropertyOptions(s),o="function"==typeof t.converter?{fromAttribute:t.converter}:void 0!==t.converter?.fromAttribute?t.converter:y;this._$Em=s;const n=o.fromAttribute(e,t.type);this[s]=n??this._$Ej?.get(s)??n,this._$Em=null}}requestUpdate(t,e,i,s=!1,o){if(void 0!==t){const n=this.constructor;if(!1===s&&(o=this[t]),i??=n.getPropertyOptions(t),!((i.hasChanged??x)(o,e)||i.useDefault&&i.reflect&&o===this._$Ej?.get(t)&&!this.hasAttribute(n._$Eu(t,i))))return;this.C(t,e,i)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(t,e,{useDefault:i,reflect:s,wrapped:o},n){i&&!(this._$Ej??=new Map).has(t)&&(this._$Ej.set(t,n??e??this[t]),!0!==o||void 0!==n)||(this._$AL.has(t)||(this.hasUpdated||i||(e=void 0),this._$AL.set(t,e)),!0===s&&this._$Em!==t&&(this._$Eq??=new Set).add(t))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}const t=this.scheduleUpdate();return null!=t&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[t,e]of this._$Ep)this[t]=e;this._$Ep=void 0}const t=this.constructor.elementProperties;if(t.size>0)for(const[e,i]of t){const{wrapped:t}=i,s=this[e];!0!==t||this._$AL.has(e)||void 0===s||this.C(e,void 0,i,s)}}let t=!1;const e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),this._$EO?.forEach(t=>t.hostUpdate?.()),this.update(e)):this._$EM()}catch(e){throw t=!1,this._$EM(),e}t&&this._$AE(e)}willUpdate(t){}_$AE(t){this._$EO?.forEach(t=>t.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Eq&&=this._$Eq.forEach(t=>this._$ET(t,this[t])),this._$EM()}updated(t){}firstUpdated(t){}};$.elementStyles=[],$.shadowRootOptions={mode:"open"},$[m("elementProperties")]=new Map,$[m("finalized")]=new Map,f?.({ReactiveElement:$}),(_.reactiveElementVersions??=[]).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const b=globalThis,w=t=>t,k=b.trustedTypes,C=k?k.createPolicy("lit-html",{createHTML:t=>t}):void 0,S="$lit$",M=`lit$${Math.random().toFixed(9).slice(2)}$`,A="?"+M,T=`<${A}>`,O=document,E=()=>O.createComment(""),P=t=>null===t||"object"!=typeof t&&"function"!=typeof t,D=Array.isArray,L="[ \t\n\f\r]",z=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Y=/-->/g,H=/>/g,N=RegExp(`>|${L}(?:([^\\s"'>=/]+)(${L}*=${L}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),U=/'/g,K=/"/g,F=/^(?:script|style|textarea|title)$/i,R=t=>(e,...i)=>({_$litType$:t,strings:e,values:i}),j=R(1),B=R(2),Z=Symbol.for("lit-noChange"),I=Symbol.for("lit-nothing"),X=new WeakMap,V=O.createTreeWalker(O,129);function W(t,e){if(!D(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==C?C.createHTML(e):e}const q=(t,e)=>{const i=t.length-1,s=[];let o,n=2===e?"<svg>":3===e?"<math>":"",a=z;for(let e=0;e<i;e++){const i=t[e];let r,l,h=-1,c=0;for(;c<i.length&&(a.lastIndex=c,l=a.exec(i),null!==l);)c=a.lastIndex,a===z?"!--"===l[1]?a=Y:void 0!==l[1]?a=H:void 0!==l[2]?(F.test(l[2])&&(o=RegExp("</"+l[2],"g")),a=N):void 0!==l[3]&&(a=N):a===N?">"===l[0]?(a=o??z,h=-1):void 0===l[1]?h=-2:(h=a.lastIndex-l[2].length,r=l[1],a=void 0===l[3]?N:'"'===l[3]?K:U):a===K||a===U?a=N:a===Y||a===H?a=z:(a=N,o=void 0);const d=a===N&&t[e+1].startsWith("/>")?" ":"";n+=a===z?i+T:h>=0?(s.push(r),i.slice(0,h)+S+i.slice(h)+M+d):i+M+(-2===h?e:d)}return[W(t,n+(t[i]||"<?>")+(2===e?"</svg>":3===e?"</math>":"")),s]};class G{constructor({strings:t,_$litType$:e},i){let s;this.parts=[];let o=0,n=0;const a=t.length-1,r=this.parts,[l,h]=q(t,e);if(this.el=G.createElement(l,i),V.currentNode=this.el.content,2===e||3===e){const t=this.el.content.firstChild;t.replaceWith(...t.childNodes)}for(;null!==(s=V.nextNode())&&r.length<a;){if(1===s.nodeType){if(s.hasAttributes())for(const t of s.getAttributeNames())if(t.endsWith(S)){const e=h[n++],i=s.getAttribute(t).split(M),a=/([.?@])?(.*)/.exec(e);r.push({type:1,index:o,name:a[2],strings:i,ctor:"."===a[1]?it:"?"===a[1]?st:"@"===a[1]?ot:et}),s.removeAttribute(t)}else t.startsWith(M)&&(r.push({type:6,index:o}),s.removeAttribute(t));if(F.test(s.tagName)){const t=s.textContent.split(M),e=t.length-1;if(e>0){s.textContent=k?k.emptyScript:"";for(let i=0;i<e;i++)s.append(t[i],E()),V.nextNode(),r.push({type:2,index:++o});s.append(t[e],E())}}}else if(8===s.nodeType)if(s.data===A)r.push({type:2,index:o});else{let t=-1;for(;-1!==(t=s.data.indexOf(M,t+1));)r.push({type:7,index:o}),t+=M.length-1}o++}}static createElement(t,e){const i=O.createElement("template");return i.innerHTML=t,i}}function J(t,e,i=t,s){if(e===Z)return e;let o=void 0!==s?i._$Co?.[s]:i._$Cl;const n=P(e)?void 0:e._$litDirective$;return o?.constructor!==n&&(o?._$AO?.(!1),void 0===n?o=void 0:(o=new n(t),o._$AT(t,i,s)),void 0!==s?(i._$Co??=[])[s]=o:i._$Cl=o),void 0!==o&&(e=J(t,o._$AS(t,e.values),o,s)),e}class Q{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:e},parts:i}=this._$AD,s=(t?.creationScope??O).importNode(e,!0);V.currentNode=s;let o=V.nextNode(),n=0,a=0,r=i[0];for(;void 0!==r;){if(n===r.index){let e;2===r.type?e=new tt(o,o.nextSibling,this,t):1===r.type?e=new r.ctor(o,r.name,r.strings,this,t):6===r.type&&(e=new nt(o,this,t)),this._$AV.push(e),r=i[++a]}n!==r?.index&&(o=V.nextNode(),n++)}return V.currentNode=O,s}p(t){let e=0;for(const i of this._$AV)void 0!==i&&(void 0!==i.strings?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}}class tt{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,e,i,s){this.type=2,this._$AH=I,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=s,this._$Cv=s?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return void 0!==e&&11===t?.nodeType&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=J(this,t,e),P(t)?t===I||null==t||""===t?(this._$AH!==I&&this._$AR(),this._$AH=I):t!==this._$AH&&t!==Z&&this._(t):void 0!==t._$litType$?this.$(t):void 0!==t.nodeType?this.T(t):(t=>D(t)||"function"==typeof t?.[Symbol.iterator])(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==I&&P(this._$AH)?this._$AA.nextSibling.data=t:this.T(O.createTextNode(t)),this._$AH=t}$(t){const{values:e,_$litType$:i}=t,s="number"==typeof i?this._$AC(t):(void 0===i.el&&(i.el=G.createElement(W(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===s)this._$AH.p(e);else{const t=new Q(s,this),i=t.u(this.options);t.p(e),this.T(i),this._$AH=t}}_$AC(t){let e=X.get(t.strings);return void 0===e&&X.set(t.strings,e=new G(t)),e}k(t){D(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let i,s=0;for(const o of t)s===e.length?e.push(i=new tt(this.O(E()),this.O(E()),this,this.options)):i=e[s],i._$AI(o),s++;s<e.length&&(this._$AR(i&&i._$AB.nextSibling,s),e.length=s)}_$AR(t=this._$AA.nextSibling,e){for(this._$AP?.(!1,!0,e);t!==this._$AB;){const e=w(t).nextSibling;w(t).remove(),t=e}}setConnected(t){void 0===this._$AM&&(this._$Cv=t,this._$AP?.(t))}}class et{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,i,s,o){this.type=1,this._$AH=I,this._$AN=void 0,this.element=t,this.name=e,this._$AM=s,this.options=o,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=I}_$AI(t,e=this,i,s){const o=this.strings;let n=!1;if(void 0===o)t=J(this,t,e,0),n=!P(t)||t!==this._$AH&&t!==Z,n&&(this._$AH=t);else{const s=t;let a,r;for(t=o[0],a=0;a<o.length-1;a++)r=J(this,s[i+a],e,a),r===Z&&(r=this._$AH[a]),n||=!P(r)||r!==this._$AH[a],r===I?t=I:t!==I&&(t+=(r??"")+o[a+1]),this._$AH[a]=r}n&&!s&&this.j(t)}j(t){t===I?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}class it extends et{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===I?void 0:t}}class st extends et{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==I)}}class ot extends et{constructor(t,e,i,s,o){super(t,e,i,s,o),this.type=5}_$AI(t,e=this){if((t=J(this,t,e,0)??I)===Z)return;const i=this._$AH,s=t===I&&i!==I||t.capture!==i.capture||t.once!==i.once||t.passive!==i.passive,o=t!==I&&(i===I||s);s&&this.element.removeEventListener(this.name,this,i),o&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}}class nt{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){J(this,t)}}const at=b.litHtmlPolyfillSupport;at?.(G,tt),(b.litHtmlVersions??=[]).push("3.3.2");const rt=globalThis;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class lt extends ${constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=((t,e,i)=>{const s=i?.renderBefore??e;let o=s._$litPart$;if(void 0===o){const t=i?.renderBefore??null;s._$litPart$=o=new tt(e.insertBefore(E(),t),t,void 0,i??{})}return o._$AI(t),o})(e,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return Z}}lt._$litElement$=!0,lt.finalized=!0,rt.litElementHydrateSupport?.({LitElement:lt});const ht=rt.litElementPolyfillSupport;ht?.({LitElement:lt}),(rt.litElementVersions??=[]).push("4.2.2");const ct={en:{loading:"Loading history data...",no_data:"No history data available",fetch_error:"Failed to fetch history data.",service_error:"Failed to start or stop the learning. Check the logs.",entity_not_found:"Entity not found:",state_active:"Active",state_off:"Off",state_disabled:"Disabled",waiting:"Waiting for update...",start_learning:"Start Learning",stop_learning:"Stop Learning",auto_tpi_disabled:"Auto TPI is not available for this entity",options:"Options",reset:"Reset",boost_kint:"boost Kint on stagnation",unboost_kext:"unboost Kext on overshoot",state:"State:",confidence:"Confidence:",cycles:"Cycles:",heat_rate:"Heat Rate",last_cycle:"Last cycle:",default_title:"Auto-TPI Learning",coef_int:"Coef INT",coef_ext:"Coef EXT",temp:"Temp",ext_temp:"Ext Temp",setpoint:"Setpoint",legend_hrate:"Hrate",legend_setpoint:"SPoint",legend_ext_temp:"ExTemp",legend_temp:"Temp",legend_heat:"Heat",editor_name:"Name",editor_climate:"Climate entity",editor_learning:"Learning entity (sensor)",editor_ext_temp:"External temperature entity (optional)"},fr:{loading:"Chargement de l'historique...",no_data:"Aucune donnée d'historique disponible",fetch_error:"Impossible de récupérer l'historique.",service_error:"Échec du démarrage ou de l'arrêt de l'apprentissage. Voir les logs.",entity_not_found:"Entité introuvable :",state_active:"Actif",state_off:"Arrêté",state_disabled:"Désactivé",waiting:"En attente de mise à jour...",start_learning:"Démarrer l'apprentissage",stop_learning:"Arrêter l'apprentissage",auto_tpi_disabled:"Auto TPI n'est pas disponible pour cette entité",options:"Options",reset:"Réinitialiser",boost_kint:"booster Kint en cas de stagnation",unboost_kext:"réduire Kext en cas de dépassement",state:"État :",confidence:"Confiance :",cycles:"Cycles :",heat_rate:"Capacité de chauffe",last_cycle:"Dernier cycle :",default_title:"Apprentissage Auto-TPI",coef_int:"Coef INT",coef_ext:"Coef EXT",temp:"Temp",ext_temp:"Temp ext",setpoint:"Consigne",legend_hrate:"Capacité",legend_setpoint:"Consigne",legend_ext_temp:"Temp ext",legend_temp:"Temp",legend_heat:"Chauffe",editor_name:"Nom",editor_climate:"Entité Climate",editor_learning:"Entité Learning (sensor)",editor_ext_temp:"Entité de température extérieure (optionnel)"},nl:{loading:"Historie laden...",no_data:"Geen historie beschikbaar",fetch_error:"Historie ophalen mislukt.",service_error:"Starten of stoppen van leren mislukt. Zie de logs.",entity_not_found:"Entiteit niet gevonden:",state_active:"Actief",state_off:"Uit",state_disabled:"Uitgeschakeld",waiting:"Wachten op update...",start_learning:"Leren starten",stop_learning:"Leren stoppen",auto_tpi_disabled:"Auto TPI is niet beschikbaar voor deze entiteit",options:"Opties",reset:"Resetten",boost_kint:"Kint verhogen bij stilstand",unboost_kext:"Kext verlagen bij doorschieten",state:"Status:",confidence:"Betrouwbaarheid:",cycles:"Cycli:",heat_rate:"Opwarmsnelheid",last_cycle:"Laatste cyclus:",default_title:"Auto-TPI leren",coef_int:"Coëf. INT",coef_ext:"Coëf. EXT",temp:"Temp",ext_temp:"Buitentemp",setpoint:"Doel",legend_hrate:"Opwarm",legend_setpoint:"Doel",legend_ext_temp:"Buiten",legend_temp:"Temp",legend_heat:"Verwarmen",editor_name:"Naam",editor_climate:"Climate-entiteit",editor_learning:"Leer-entiteit (sensor)",editor_ext_temp:"Entiteit buitentemperatuur (optioneel)"}},dt={en:{learning_started:"learning started",learning_resumed:"learning resumed",learning_stopped:"learning stopped",not_heating_or_cooling:"not heating or cooling",setpoint_changed_during_cycle:"setpoint changed during cycle",consigne_changed:"setpoint changed",learned_indoor_heat:"learned indoor coefficient (heat)",learned_indoor_cool:"learned indoor coefficient (cool)",learned_outdoor_heat:"learned outdoor coefficient (heat)",learned_outdoor_cool:"learned outdoor coefficient (cool)",continuous_kext_learned_heat:"learned outdoor coefficient continuously (heat)",continuous_kext_learned_cool:"learned outdoor coefficient continuously (cool)",cycle_too_short:"cycle too short",cycle_gap_detected:"gap between cycles detected",real_rise_too_small:"temperature rise too small",warming_up_naturally:"warming up naturally",cooling_down_naturally:"cooling down naturally",anomalous_overheating:"anomalous overheating",anomalous_overcooling:"anomalous overcooling"},fr:{learning_started:"apprentissage démarré",learning_resumed:"apprentissage repris",learning_stopped:"apprentissage arrêté",not_heating_or_cooling:"ni chauffe ni refroidissement",setpoint_changed_during_cycle:"consigne modifiée pendant le cycle",consigne_changed:"consigne modifiée",learned_indoor_heat:"coefficient intérieur appris (chauffe)",learned_indoor_cool:"coefficient intérieur appris (clim)",learned_outdoor_heat:"coefficient extérieur appris (chauffe)",learned_outdoor_cool:"coefficient extérieur appris (clim)",continuous_kext_learned_heat:"coefficient extérieur appris en continu (chauffe)",continuous_kext_learned_cool:"coefficient extérieur appris en continu (clim)",cycle_too_short:"cycle trop court",cycle_gap_detected:"interruption entre cycles détectée",real_rise_too_small:"hausse de température trop faible",warming_up_naturally:"réchauffement naturel",cooling_down_naturally:"refroidissement naturel",anomalous_overheating:"surchauffe anormale",anomalous_overcooling:"refroidissement anormal"},nl:{learning_started:"leren gestart",learning_resumed:"leren hervat",learning_stopped:"leren gestopt",not_heating_or_cooling:"niet aan het verwarmen of koelen",setpoint_changed_during_cycle:"doeltemperatuur gewijzigd tijdens cyclus",consigne_changed:"doeltemperatuur gewijzigd",learned_indoor_heat:"binnencoëfficiënt geleerd (verwarmen)",learned_indoor_cool:"binnencoëfficiënt geleerd (koelen)",learned_outdoor_heat:"buitencoëfficiënt geleerd (verwarmen)",learned_outdoor_cool:"buitencoëfficiënt geleerd (koelen)",continuous_kext_learned_heat:"buitencoëfficiënt continu geleerd (verwarmen)",continuous_kext_learned_cool:"buitencoëfficiënt continu geleerd (koelen)",cycle_too_short:"cyclus te kort",cycle_gap_detected:"onderbreking tussen cycli gedetecteerd",real_rise_too_small:"temperatuurstijging te klein",warming_up_naturally:"warmt vanzelf op",cooling_down_naturally:"koelt vanzelf af",anomalous_overheating:"afwijkende oververhitting",anomalous_overcooling:"afwijkende onderkoeling"}};function pt(t){const e=(t?.locale?.language||t?.language||"en").split("-")[0];return ct[e]?e:"en"}function _t(t){return t?.locale?.language||t?.language||"en"}function ut(t,e){const i=pt(t);return ct[i][e]??ct.en[e]??e}class gt extends lt{static properties={hass:{type:Object},config:{type:Object},_history:{type:Object},_loading:{type:Boolean},_error:{type:String},_showTemp:{type:Boolean},_showHeating:{type:Boolean},_showSetpoint:{type:Boolean},_showKint:{type:Boolean},_showKext:{type:Boolean},_showExtTemp:{type:Boolean},_showMaxCapacity:{type:Boolean},_lastFetchTime:{type:Number},_lastStartDt:{type:String},_tooltip:{type:Object},_width:{type:Number},_zoomLevel:{type:Number},_panOffset:{type:Number},_isDragging:{type:Boolean},_dragStartX:{type:Number},_dragStartOffset:{type:Number},_yZoomLevel:{type:Number},_yPanOffset:{type:Number},_isYDragging:{type:Boolean},_dragStartY:{type:Number},_dragStartYOffset:{type:Number},_isPinching:{type:Boolean},_pinchStartDist:{type:Number},_pinchStartZoom:{type:Number},_pinchStartYZoom:{type:Number},_resetChecked:{type:Boolean},_boostKintChecked:{type:Boolean},_unboostKextChecked:{type:Boolean},_showOptions:{type:Boolean}};static getConfigElement(){return document.createElement("auto-tpi-learning-card-editor")}static getStubConfig(){return{learning_entity:"",climate_entity:"",ext_temp_entity:"",name:""}}constructor(){super(),this._history=null,this._loading=!1,this._error=null,this._showTemp=!0,this._showHeating=!0,this._showSetpoint=!0,this._showKint=!0,this._showKext=!0,this._showExtTemp=!0,this._showMaxCapacity=!0,this._lastFetchTime=0,this._lastStartDt=null,this._tooltip=null,this._width=1,this._resizeObserver=null,this._zoomLevel=1,this._panOffset=0,this._isDragging=!1,this._dragStartX=0,this._dragStartOffset=0,this._yZoomLevel=1,this._yPanOffset=0,this._isYDragging=!1,this._dragStartY=0,this._dragStartYOffset=0,this._resetChecked=!1,this._boostKintChecked=!1,this._unboostKextChecked=!1,this._showOptions=!1}connectedCallback(){super.connectedCallback(),this._resizeObserver=new ResizeObserver(t=>{for(let e of t)e.contentRect.width>0&&(this._width=e.contentRect.width)}),this._resizeObserver.observe(this)}disconnectedCallback(){super.disconnectedCallback(),this._resizeObserver&&this._resizeObserver.disconnect()}setConfig(t){if(!t.learning_entity)throw new Error("You need to define learning_entity");if(!t.climate_entity)throw new Error("You need to define climate_entity");this.config=t,this._history=null,this._lastFetchTime=0,this._lastStartDt=null}getCardSize(){}getLayoutOptions(){return{}}shouldUpdate(t){return!0}willUpdate(t){(t.has("_width")||t.has("_zoomLevel")||t.has("_panOffset")||t.has("_yZoomLevel")||t.has("_yPanOffset")||t.has("_history"))&&(this._chartState=null,this._staticChartContent=null),(t.has("_showTemp")||t.has("_showHeating")||t.has("_showSetpoint")||t.has("_showKint")||t.has("_showKext")||t.has("_showExtTemp")||t.has("_showMaxCapacity"))&&(this._staticChartContent=null)}updated(t){if(super.updated(t),!t.has("hass")||!this.hass||!this.config)return;const e=this.config.learning_entity,i=this.hass.states[e],s=!!i,o=i?.attributes?.learning_start_dt||null,n=o?new Date(o).getTime():null,a=this._lastStartDt?new Date(this._lastStartDt).getTime():null;if(null!==n&&Number.isFinite(n)&&null!==a&&Number.isFinite(a)&&Math.abs(n-a)>1e3&&(this._history=null),this._history&&null!=this._history.startTime&&null!==n&&Number.isFinite(n)&&Math.abs(this._history.startTime-n)>1e3&&(this._history=null),null!==n&&Number.isFinite(n)&&(this._lastStartDt=o),!s||null===n&&this._history)return;const r=Date.now()-this._lastFetchTime>3e5,l=this._history&&this._history.endTime;(!this._history||r&&!l)&&!this._loading&&this._fetchHistory()}async _fetchHistory(){if(!this._loading&&this.hass&&this.config){this._loading=!0,this._error=null;try{const t=this.config.learning_entity,e=this.config.climate_entity,i=this.config.ext_temp_entity||null;e&&!this.hass.states[e]&&console.warn(`Auto-TPI card: climate entity "${e}" is not available; temperature and setpoint curves cannot be built.`);const s=this.hass.states[t];let o,n=s?.attributes?.learning_start_dt;o=n?new Date(n):new Date(Date.now()-864e5);const a=o.toISOString(),r=(new Date).toISOString(),l=`history/period/${a}?filter_entity_id=${[t,e,i].filter(t=>!!t).join(",")}&end_time=${r}&significant_changes_only=0`,h=await this.hass.callApi("GET",l);this._processHistory(h,t,e,i,o),this._lastFetchTime=Date.now(),this._history&&0===this._history.temp.length&&console.warn(`Auto-TPI card: no indoor temperature found for "${e}" in the history period.`)}catch(t){console.error("Error fetching history:",t),this._error=ut(this.hass,"fetch_error")}finally{this._loading=!1}}}_bisectLeft(t,e){let i=0,s=t.length;for(;i<s;){const o=i+s>>>1;t[o].t<e?i=o+1:s=o}return i}_bisectRight(t,e){let i=0,s=t.length;for(;i<s;){const o=i+s>>>1;t[o].t<=e?i=o+1:s=o}return i-1}_getVisibleData(t,e,i){if(!t||0===t.length)return[];let s=this._bisectLeft(t,e),o=this._bisectRight(t,i);return s=Math.max(0,s-1),o=Math.min(t.length-1,o+1),s>o?[]:t.slice(s,o+1)}_processHistory(t,e,i,s,o){if(!Array.isArray(t))return void(this._history={kint:[],kext:[],temp:[],heating:[],setpoint:[],extTemp:[],maxCapacity:[],startTime:o.getTime()});const n={kint:[],kext:[],temp:[],heating:[],setpoint:[],extTemp:[],maxCapacity:[]};let a=null;const r=(t,e,i)=>{const s=parseFloat(i);isNaN(s)||t.push({t:e,val:s})};for(const o of t){if(!o||0===o.length)continue;const t=o[0].entity_id,l=this._entityIdMatches(t,e),h=this._entityIdMatches(t,i),c=this._entityIdMatches(t,s);if(l||h||c)for(const t of o){const e=new Date(t.last_updated).getTime(),i=t.attributes;if(i)if(l){const s=i.coeff_int_cycles||0,o=i.coeff_ext_cycles||0;"off"===this._normalizeState(t.state)&&s>=50&&o>=50&&(null===a||e<a)&&(a=e),null!=i.calculated_coef_int&&r(n.kint,e,i.calculated_coef_int),null!=i.calculated_coef_ext&&r(n.kext,e,i.calculated_coef_ext),null!=i.max_capacity_heat&&r(n.maxCapacity,e,i.max_capacity_heat)}else if(c)r(n.extTemp,e,t.state);else{let t=null;null!=i.current_temperature?t=i.current_temperature:null!=i.ema_temp&&(t=i.ema_temp),null!=t&&r(n.temp,e,t);let s=null;null!=i.temperature?s=i.temperature:null!=i.current_state?.target_temperature?s=i.current_state.target_temperature:null!=i.requested_state?.target_temperature&&(s=i.requested_state.target_temperature),null!=s&&r(n.setpoint,e,s),void 0!==i.hvac_action&&n.heating.push({t:e,val:"heating"===i.hvac_action?1:0})}}}for(const t in n)n[t].sort((t,e)=>t.t-e.t);const l=this.hass.states[e];if(l){const t="off"===this._normalizeState(l.state),e=l.attributes.coeff_int_cycles||0,i=l.attributes.coeff_ext_cycles||0;t&&e>=50&&i>=50||(a=null)}this._history={...n,startTime:o.getTime(),endTime:a}}_getLearningData(){const t=this.hass.states[this.config.learning_entity];return t?{state:t.state,kint:parseFloat(t.attributes.calculated_coef_int)||0,kext:parseFloat(t.attributes.calculated_coef_ext)||0,kintCycles:t.attributes.coeff_int_cycles||0,kextCycles:t.attributes.coeff_ext_cycles||0,confidence:parseFloat(t.attributes.model_confidence)||0,status:t.attributes.last_learning_status||"",learningStartDt:t.attributes.learning_start_dt||"",learningDone:t.attributes.learning_done,allowKintBoost:t.attributes.allow_kint_boost_on_stagnation,allowKextCompensation:t.attributes.allow_kext_compensation_on_overshoot}:null}_normalizeState(t){return null==t?"":t.toString().toLowerCase()}_entityIdMatches(t,e){return!(!t||!e)&&t.trim().toLowerCase()===e.trim().toLowerCase()}_getCurrentMaxCapacity(){const t=this.hass.states[this.config.learning_entity].attributes.max_capacity_heat;return null==t?"N/A":parseFloat(t).toFixed(2)}_toggleAutoTpi(t){if(!this.hass||!this.config)return;const e={entity_id:this.config.climate_entity};let i;i=t?{auto_tpi_mode:!1,reinitialise:!1}:{auto_tpi_mode:!0,reinitialise:this._resetChecked,allow_kint_boost_on_stagnation:this._boostKintChecked,allow_kext_compensation_on_overshoot:this._unboostKextChecked},this.hass.callService("versatile_thermostat","set_auto_tpi_mode",i,e).catch(t=>{console.error("Error calling versatile_thermostat.set_auto_tpi_mode:",t),this._notify(ut(this.hass,"service_error"))}),this._resetChecked=!1}_notify(t){this.dispatchEvent(new CustomEvent("hass-notification",{detail:{message:t},bubbles:!0,composed:!0}))}_toggleResetCheckbox(){this._resetChecked=!this._resetChecked,this.requestUpdate()}_toggleBoostKintCheckbox(){this._boostKintChecked=!this._boostKintChecked,this.requestUpdate()}_toggleUnboostKextCheckbox(){this._unboostKextChecked=!this._unboostKextChecked,this.requestUpdate()}_toggleOptions(){this._showOptions=!this._showOptions}_toggleHeating(){this._showHeating=!this._showHeating}_toggleSetpoint(){this._showSetpoint=!this._showSetpoint}_toggleKint(){this._showKint=!this._showKint}_toggleKext(){this._showKext=!this._showKext}_toggleExtTemp(){this._showExtTemp=!this._showExtTemp}_toggleMaxCapacity(){this._showMaxCapacity=!this._showMaxCapacity}_toggleTemp(){this._showTemp=!this._showTemp}_handleWheel(t){if(t.preventDefault(),!this._history)return;const e=t.currentTarget.getBoundingClientRect(),i=t.clientX-e.left,s=t.clientY-e.top,o=60,n=100,a=40,r=60,l=e.width-o-n,h=e.height-a-r,c=Math.max(0,Math.min(1,(i-o)/l)),d=this._history.endTime||Date.now(),p=this._history.startTime,_=Math.max(d-p,216e5),u=_/this._zoomLevel,g=p+this._panOffset+c*u,f=this._getYValueFromPosition(s,a,h),m=t.deltaY>0?.9:1.1,y=Math.max(1,Math.min(20,this._zoomLevel*m)),x=Math.max(1,Math.min(20,this._yZoomLevel*m));this._zoomLevel=y,this._yZoomLevel=x;const v=_/y;this._panOffset=g-p-c*v;const $=a+h/2,b=a+h-f*h;this._yPanOffset=s-($+(b-$)*this._yZoomLevel),1===this._zoomLevel&&(this._panOffset=0),1===this._yZoomLevel&&(this._yPanOffset=0),this._clampPanOffset(),this._tooltip=null,this.requestUpdate()}_zoomIn(){this._zoomLevel=Math.min(20,1.2*this._zoomLevel),this._yZoomLevel=Math.min(20,1.2*this._yZoomLevel),this._clampPanOffset(),this._clampYPanOffset(),this.requestUpdate()}_zoomOut(){this._zoomLevel=Math.max(1,this._zoomLevel/1.2),this._yZoomLevel=Math.max(1,this._yZoomLevel/1.2),1===this._zoomLevel&&(this._panOffset=0),1===this._yZoomLevel&&(this._yPanOffset=0),this._clampPanOffset(),this._clampYPanOffset(),this.requestUpdate()}_resetZoom(){this._zoomLevel=1,this._panOffset=0,this._yZoomLevel=1,this._yPanOffset=0}_clampPanOffset(){if(!this._history)return;const t=(this._history.endTime||Date.now())-this._history.startTime,e=Math.max(t,216e5),i=e-e/this._zoomLevel;this._panOffset=Math.max(0,Math.min(i,this._panOffset))}_clampYPanOffset(){this._yPanOffset=Math.max(-1e4,Math.min(1e4,this._yPanOffset))}_applyYZoom(t,e,i){if(1===this._yZoomLevel&&0===this._yPanOffset)return t;const s=e+i/2;return s+(t-s)*this._yZoomLevel+this._yPanOffset}_getYValueFromPosition(t,e,i){const s=e+i/2;return(e+i-(s+(t-this._yPanOffset-s)/this._yZoomLevel))/i}_getSVGPoint(t,e,i){const s=t.createSVGPoint();return s.x=e,s.y=i,s.matrixTransform(t.getScreenCTM().inverse())}_handleTouchMove(t){t.preventDefault();const e=t.currentTarget,i=t.touches[0],{x:s,y:o}=this._getSVGPoint(e,i.clientX,i.clientY);this._processCursorMove(s,o)}_handleMouseMove(t){const e=t.currentTarget,{x:i,y:s}=this._getSVGPoint(e,t.clientX,t.clientY);this._processCursorMove(i,s)}_handleMouseDown(t){this._isDragging=!0,this._dragStartX=t.clientX,this._dragStartY=t.clientY,this._dragStartOffset=this._panOffset,this._dragStartYOffset=this._yPanOffset,t.currentTarget.style.cursor="grabbing"}_handleMouseMove_Drag(t){if(!this._isDragging||!this._history)return;const e=60,i=100,s=t.currentTarget.getBoundingClientRect().width-e-i,o=this._dragStartX-t.clientX,n=this._dragStartY-t.clientY,a=this._history.endTime||Date.now(),r=this._history.startTime,l=o/s*(Math.max(a-r,216e5)/this._zoomLevel);this._panOffset=this._dragStartOffset+l,this._clampPanOffset(),this._yZoomLevel>1&&(this._yPanOffset=this._dragStartYOffset-n)}_handleMouseUp(t){this._isDragging=!1,t.currentTarget.style.cursor="default"}_handleTouchStart(t){if(1===t.touches.length)this._isDragging=!0,this._isPinching=!1,this._dragStartX=t.touches[0].clientX,this._dragStartY=t.touches[0].clientY,this._dragStartOffset=this._panOffset,this._dragStartYOffset=this._yPanOffset;else if(2===t.touches.length){this._isDragging=!1,this._isPinching=!0;const e=t.touches[0].clientX-t.touches[1].clientX,i=t.touches[0].clientY-t.touches[1].clientY;this._pinchStartDist=Math.hypot(e,i),this._pinchStartZoom=this._zoomLevel,this._pinchStartYZoom=this._yZoomLevel}}_handleTouchMove_Drag(t){if(!this._history)return;const e=t.currentTarget.getBoundingClientRect(),i=60,s=100,o=40,n=60,a=e.width-i-s,r=e.height-o-n;if(this._isDragging&&1===t.touches.length){t.preventDefault();const e=this._dragStartX-t.touches[0].clientX,i=this._dragStartY-t.touches[0].clientY,s=this._history.endTime||Date.now(),o=this._history.startTime,n=e/a*(Math.max(s-o,216e5)/this._zoomLevel);this._panOffset=this._dragStartOffset+n,this._clampPanOffset(),this._yZoomLevel>1&&(this._yPanOffset=this._dragStartYOffset-i)}else if(this._isPinching&&2===t.touches.length){t.preventDefault();const s=t.touches[0],n=t.touches[1],l=s.clientX-n.clientX,h=s.clientY-n.clientY,c=Math.hypot(l,h);if(this._pinchStartDist<=10)return;const d=c/this._pinchStartDist,p=(s.clientX+n.clientX)/2,_=(s.clientY+n.clientY)/2,u=p-e.left,g=_-e.top,f=Math.max(0,Math.min(1,(u-i)/a)),m=this._history.endTime||Date.now(),y=this._history.startTime,x=Math.max(m-y,216e5),v=x/this._zoomLevel,$=y+this._panOffset+f*v,b=this._getYValueFromPosition(g,o,r),w=Math.max(1,Math.min(20,this._pinchStartZoom*d)),k=Math.max(1,Math.min(20,this._pinchStartYZoom*d));this._zoomLevel=w,this._yZoomLevel=k;const C=x/w;this._panOffset=$-y-f*C;const S=o+r/2,M=o+r-b*r;this._yPanOffset=g-(S+(M-S)*this._yZoomLevel),1===this._zoomLevel&&(this._panOffset=0),1===this._yZoomLevel&&(this._yPanOffset=0),this._clampPanOffset(),this._clampYPanOffset(),this.requestUpdate()}}_handleTouchEnd(t){0===t.touches.length?(this._isDragging=!1,this._isPinching=!1):1===t.touches.length&&this._isPinching&&(this._isPinching=!1,this._isDragging=!0,this._dragStartX=t.touches[0].clientX,this._dragStartY=t.touches[0].clientY,this._dragStartOffset=this._panOffset,this._dragStartYOffset=this._yPanOffset)}_processCursorMove(t,e){if(!this._chartState)return;const{xMin:i,xMax:s,chartWidth:o,chartHeight:n,padding:a,kint:r,kext:l,temp:h,extTemp:c,setpoint:d,maxCapacity:p,getY_Kint:_,getY_Kext:u,getY_Temp:g,getY_MaxCapacity:f}=this._chartState,m=t-a.left;if(m<0||m>o)return void(this._tooltip=null);const y=i+m/o*(s-i),x=(t,e)=>{if(!t||0===t.length)return null;const i=this._bisectRight(t,e);return i>=0&&i<t.length?t[i].val:null},v=(t,e)=>{if(!t||0===t.length)return null;const i=this._bisectRight(t,e);if(i<0)return t[0].val;if(i>=t.length-1)return t[t.length-1].val;const s=t[i],o=t[i+1],n=s.t,a=o.t,r=s.val,l=o.val;if(a===n)return r;return r+(l-r)*((e-n)/(a-n))},$=this._showKint?x(r,y):null,b=this._showKext?x(l,y):null,w=this._showTemp?v(h,y):null,k=this._showExtTemp?v(c,y):null,C=this._showSetpoint?x(d,y):null,S=this._showMaxCapacity?v(p,y):null;let M=1/0,A=1/0,T=1/0,O=1/0,E=1/0,P=1/0;null!==$&&(M=_($)),null!==b&&(A=u(b)),null!==w&&(T=g(w)),null!==k&&(O=g(k)),null!==C&&(E=g(C)),null!==S&&(P=f(S));const D=Math.abs(e-M),L=Math.abs(e-A),z=Math.abs(e-T),Y=Math.abs(e-O),H=Math.abs(e-E),N=Math.abs(e-P);let U="kint",K=D;if(L<K&&(K=L,U="kext"),z<K&&(K=z,U="temp"),Y<K&&(K=Y,U="extTemp"),H<K&&(K=H,U="setpoint"),N<K&&(K=N,U="maxCapacity"),K>50)return void(this._tooltip=null);let F=$,R="var(--chart-color-kint)",j=ut(this.hass,"coef_int"),B=M,Z=4;"kext"===U?(F=b,R="var(--chart-color-kext)",j=ut(this.hass,"coef_ext"),B=A):"temp"===U?(F=w,R="var(--chart-color-temp)",j=ut(this.hass,"temp"),B=T,Z=1):"extTemp"===U?(F=k,R="var(--chart-color-ext-temp)",j=ut(this.hass,"ext_temp"),B=O,Z=1):"setpoint"===U?(F=C,R="var(--chart-color-setpoint)",j=ut(this.hass,"setpoint"),B=E,Z=1):"maxCapacity"===U&&(F=S,R="var(--chart-color-max-capacity)",j=ut(this.hass,"heat_rate"),B=P,Z=2),this._tooltip=null!==F?{x:t,y:e,t:y,value:F,color:R,title:j,targetY:B,precision:Z}:null}_handleMouseLeave(){this._tooltip=null}_renderTooltip(){if(!this._tooltip||null===this._tooltip.value)return j``;const t=new Date(this._tooltip.t).toLocaleString(_t(this.hass),{day:"numeric",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit"}),{x:e,targetY:i}=this._tooltip,s=this._width>0?this._width:800,o=e>s/2;return j`
      <div class="tooltip" style="
        left: ${o?"auto":`${e+20}px`};
        right: ${o?s-e+20+"px":"auto"};
        top: ${`${i}px`};
        transform: ${"translate(0, -50%)"};
        border-left: 5px solid ${this._tooltip.color};
      ">
        <div style="font-weight: bold; font-size: 1.1em; margin-bottom: 2px;">${this._tooltip.title}</div>
        <div style="font-size: 0.9em; opacity: 0.8; margin-bottom: 4px;">${t}</div>
        <div style="font-weight: bold; font-size: 1.2em;">${this._tooltip.value.toFixed(this._tooltip.precision)}</div>
      </div>
    `}_calculateChartState(){if(!this._history)return null;const{kint:t,kext:e,temp:i,heating:s,setpoint:o,extTemp:n,maxCapacity:a}=this._history,r=this._width>0?this._width:800,l={top:10,right:100,bottom:40,left:60},h=r-l.left-l.right,c=300-l.top-l.bottom,d=this._history.endTime||Date.now();let p=this._history.startTime,_=d;const u=216e5,g=d-p;d-p<u&&(_=p+u);const f=Math.max(g,u)/this._zoomLevel;let m=p+this._panOffset,y=m+f;let x=0,v=1;if(t.length>0){let e=1/0,i=-1/0;for(const s of t)s.val<e&&(e=s.val),s.val>i&&(i=s.val);x=Math.min(0,e),v=Math.max(1,i),v>1&&(v=Math.ceil(10*v)/10)}let $=0,b=.1;if(e.length>0){let t=1/0,i=-1/0;for(const s of e)s.val<t&&(t=s.val),s.val>i&&(i=s.val);$=Math.min(0,t),b=Math.max(.1,i),b>.1&&(b=Math.ceil(100*b)/100)}let w=-20,k=40;const C=[...i,...n,...o];if(C.length>0){const t=Math.min(...C.map(t=>t.val)),e=Math.max(...C.map(t=>t.val));if(w=Math.max(-20,Math.floor(t-1)),k=Math.min(40,Math.ceil(e+1)),k-w<5){const t=(w+k)/2;w=Math.max(-20,t-2.5),k=Math.min(40,t+2.5)}}let S=0,M=1;if(a.length>0){const t=Math.min(...a.map(t=>t.val)),e=Math.max(...a.map(t=>t.val));if(S=Math.max(0,Math.floor(t-.5)),M=Math.min(10,Math.ceil(e+.5)),M-S<1){const t=(S+M)/2;S=Math.max(0,t-.5),M=Math.min(10,t+.5)}}return{width:r,height:300,padding:l,chartWidth:h,chartHeight:c,xMin:m,xMax:y,getX:t=>y===m?l.left:l.left+(t-m)/(y-m)*h,getY_Kint:t=>{const e=l.top+c-(t-x)/(v-x)*c;return this._applyYZoom(e,l.top,c)},getY_Kext:t=>{const e=l.top+c-(t-$)/(b-$)*c;return this._applyYZoom(e,l.top,c)},getY_Temp:t=>{if(k===w)return l.top+c/2;const e=l.top+c-(t-w)/(k-w)*c;return this._applyYZoom(e,l.top,c)},getY_MaxCapacity:t=>{if(M===S)return l.top+c/2;const e=l.top+c-(t-S)/(M-S)*c;return this._applyYZoom(e,l.top,c)},kintMin:x,kintMax:v,kextMin:$,kextMax:b,maxCapacityMin:S,maxCapacityMax:M,kint:t,kext:e,temp:i,heating:s,setpoint:o,extTemp:n,maxCapacity:a}}_generateStaticContent(t){if(!t)return B``;const{width:e,height:i,padding:s,chartWidth:o,chartHeight:n,xMin:a,xMax:r,getX:l,getY_Kint:h,getY_Kext:c,getY_Temp:d,getY_MaxCapacity:p,kintMin:_,kintMax:u,kextMin:g,kextMax:f,maxCapacityMin:m,maxCapacityMax:y,kint:x,kext:v,temp:$,heating:b,setpoint:w,extTemp:k,maxCapacity:C}=t,S=(t,e)=>0===t.length?"":t.map((t,i)=>`${0===i?"M":"L"} ${l(t.t).toFixed(1)},${e(t.val).toFixed(1)}`).join(" "),M=(t,e)=>{if(0===t.length)return"";let i=`M ${l(t[0].t).toFixed(1)},${e(t[0].val).toFixed(1)}`;for(let s=0;s<t.length-1;s++){const o=t[s],n=t[s+1];i+=` L ${l(n.t).toFixed(1)},${e(o.val).toFixed(1)}`,i+=` L ${l(n.t).toFixed(1)},${e(n.val).toFixed(1)}`}const s=t[t.length-1],o=this._history?.endTime||Date.now();return o>s.t&&(i+=` L ${l(o).toFixed(1)},${e(s.val).toFixed(1)}`),i},A=this._showKint?this._getVisibleData(x,a,r):[],T=this._showKext?this._getVisibleData(v,a,r):[],O=this._showTemp?this._getVisibleData($,a,r):[],E=this._showExtTemp?this._getVisibleData(k,a,r):[],P=this._showSetpoint?this._getVisibleData(w,a,r):[],D=this._showMaxCapacity?this._getVisibleData(C,a,r):[],L=A.length>0?M(A,h):"",z=T.length>0?M(T,c):"",Y=O.length>0?S(O,d):"",H=E.length>0?S(E,d):"",N=P.length>0?M(P,d):"",U=P.length>0?((t,e)=>{if(0===t.length)return"";let i=`M ${l(t[0].t).toFixed(1)},${s.top+n}`;for(let s=0;s<t.length-1;s++){const o=t[s],n=t[s+1];i+=` L ${l(n.t).toFixed(1)},${e(o.val).toFixed(1)}`,i+=` L ${l(n.t).toFixed(1)},${e(n.val).toFixed(1)}`}const o=t[t.length-1],a=this._history?.endTime||Date.now();return a>o.t&&(i+=` L ${l(a).toFixed(1)},${e(o.val).toFixed(1)}`),i+=` L ${l(t[t.length-1].t).toFixed(1)},${s.top+n}`,i+=` L ${l(t[0].t).toFixed(1)},${s.top+n} Z`,i})(P,d):"",K=D.length>0?S(D,p):"",F=[];if(this._showHeating&&b.length>0){const t=e-s.right;let i=this._bisectLeft(b,a),o=this._bisectRight(b,r);i=Math.max(0,i-1),o=Math.min(b.length-1,o+1);for(let e=i;e<=o;e++)if(b[e]&&1===b[e].val){const i=b[e].t,o=e<b.length-1?b[e+1].t:this._history?.endTime||Date.now();if(o<a||i>r)continue;const h=l(i),c=l(o),d=Math.max(s.left,Math.min(h,c)),p=Math.min(t,Math.max(h,c))-d;p>0&&F.push(B`
              <rect
                x="${d}"
                y="${s.top+n-20}"
                width="${p}"
                height="20"
                fill="var(--chart-color-heating)"
                clip-path="url(#chart-clip)"
              />
            `)}}const R=[],j=u>2?.5:.25;for(let t=Math.ceil(_/j)*j;t<=u+.001;t+=j)R.push(t);const Z=R.map(t=>{const i=h(t);return B`
        <line x1="${s.left}" y1="${i}" x2="${e-s.right}" y2="${i}" stroke="var(--chart-color-grid)" stroke-width="1" opacity="0.3" />
        <text x="${s.left-8}" y="${i+5}" text-anchor="end" font-size="12" fill="var(--chart-color-kint)" opacity="0.9">${t.toFixed(2)}</text>
      `}),I=[],X=f>.5?.1:.05;for(let t=Math.ceil(g/X)*X;t<=f+1e-4;t+=X)I.push(t);const V=I.map(t=>{const i=c(t);return B`
        <text x="${e-s.right+8}" y="${i+5}" text-anchor="start" font-size="12" fill="var(--chart-color-kext)" opacity="0.9">${t.toFixed(2)}</text>
      `}),W=[],q=y>2?1:.5;for(let t=Math.ceil(m/q)*q;t<=y+.001;t+=q)W.push(t);const G=W.map(t=>{const i=p(t);return B`
        <line x1="${s.left}" y1="${i}" x2="${e-s.right}" y2="${i}" stroke="var(--chart-color-grid)" stroke-width="1" opacity="0.2" />
        <text x="${e-s.right+42}" y="${i+5}" text-anchor="start" font-size="12" fill="var(--chart-color-max-capacity)" opacity="0.9">${t.toFixed(1)}</text>
      `}),J=[],Q=r-a,tt=Math.min(10,Math.max(2,Math.floor(o/80)+1)),et=Q/(tt-1),it=864e5,st=[36e5,72e5,108e5,144e5,216e5,432e5,864e5].find(t=>et<=t)||Math.ceil(et/it)*it,ot=new Date(a);if(st>=it)ot.setHours(0,0,0,0),ot.getTime()<a&&ot.setDate(ot.getDate()+1);else{const t=st/36e5;ot.setHours(Math.floor(ot.getHours()/t)*t,0,0,0),ot.getTime()<a&&ot.setTime(ot.getTime()+st)}let nt=ot.getTime();for(;nt<=r&&J.length<tt;){const t=new Date(nt),e=l(nt),o=`${t.getHours().toString().padStart(2,"0")}:${t.getMinutes().toString().padStart(2,"0")}`;let a="";if(0===t.getHours()||st>=it){const e={day:"numeric",month:"short"};a=t.toLocaleDateString(_t(this.hass),e)}J.push(B`
        <line x1="${e}" y1="${s.top+n}" x2="${e}" y2="${s.top+n+5}" stroke="var(--chart-color-time-label)" stroke-width="1" />
        <text x="${e}" y="${i-18}" text-anchor="middle" font-size="12" fill="var(--chart-color-time-label)">${o}</text>
        ${a?B`<text x="${e}" y="${i-4}" text-anchor="middle" font-size="10" fill="var(--chart-color-sub-label)">${a}</text>`:""}
      `),nt+=st}return B`
      <defs>
        <clipPath id="chart-clip">
          <rect x="${s.left}" y="${s.top}" width="${o}" height="${n}" />
        </clipPath>
      </defs>

      ${Z}
      ${V}
      ${G}
      ${J}

      <rect x="${s.left}" y="${s.top}" width="${o}" height="${n}" fill="transparent" stroke="var(--chart-color-grid)" stroke-width="1" opacity="0.5" />

      ${F}
      ${U?B`<path d="${U}" fill="var(--chart-color-setpoint-fill)" stroke="none" style="pointer-events: none;" clip-path="url(#chart-clip)" />`:""}
      ${N?B`<path d="${N}" fill="none" stroke="var(--chart-color-setpoint)" stroke-width="2" style="pointer-events: none;" clip-path="url(#chart-clip)" />`:""}
      ${Y?B`<path d="${Y}" fill="none" stroke="var(--chart-color-temp)" stroke-width="1.5" opacity="0.7" style="pointer-events: none;" clip-path="url(#chart-clip)" />`:""}
      ${H?B`<path d="${H}" fill="none" stroke="var(--chart-color-ext-temp)" stroke-width="1.5" opacity="0.9" style="pointer-events: none;" clip-path="url(#chart-clip)" />`:""}
      ${K?B`<path d="${K}" fill="none" stroke="var(--chart-color-max-capacity)" stroke-width="2" stroke-dasharray="5,5" style="pointer-events: none;" clip-path="url(#chart-clip)" />`:""}
      ${z?B`<path d="${z}" fill="none" stroke="var(--chart-color-kext)" stroke-width="2" style="pointer-events: none;" clip-path="url(#chart-clip)" />`:""}
      ${L?B`<path d="${L}" fill="none" stroke="var(--chart-color-kint)" stroke-width="2.5" style="pointer-events: none;" clip-path="url(#chart-clip)" />`:""}
    `}_renderChart(){if(this._loading)return j`<div class="loading">${ut(this.hass,"loading")}</div>`;if(this._error)return j`<div class="error">${this._error}</div>`;if(!this._history||0===this._history.kint.length&&0===this._history.kext.length)return j`<div class="no-data">${ut(this.hass,"no_data")}</div>`;this._chartState||(this._chartState=this._calculateChartState()),!this._staticChartContent&&this._chartState&&(this._staticChartContent=this._generateStaticContent(this._chartState));const{height:t,width:e}=this._chartState,i=this._chartState.padding;let s=B``;if(this._tooltip&&null!==this._tooltip.value){const e=this._tooltip.x,o=this._tooltip.targetY;s=B`
        <g style="pointer-events: none;">
          <line x1="${e}" y1="${i.top}" x2="${e}" y2="${t-i.bottom}" stroke="var(--secondary-text-color)" stroke-width="1" stroke-dasharray="4" opacity="0.3" />
          <circle cx="${e}" cy="${o}" r="6" fill="white" stroke="${this._tooltip.color}" stroke-width="3" />
        </g>
      `}return j`
      <svg
        width="100%"
        height="${t}"
        viewBox="0 0 ${e} ${t}"
        preserveAspectRatio="xMidYMid meet"
        style="cursor: ${this._isDragging?"grabbing":"default"}; overflow: hidden; touch-action: none;"
        @wheel="${t=>this._handleWheel(t)}"
        @mousedown="${t=>this._handleMouseDown(t)}"
        @mousemove="${t=>{this._handleMouseMove_Drag(t),this._isDragging||this._handleMouseMove(t)}}"
        @mouseup="${t=>this._handleMouseUp(t)}"
        @mouseleave="${t=>{this._handleMouseUp(t),this._handleMouseLeave()}}"
        @touchstart="${t=>this._handleTouchStart(t)}"
        @touchmove="${t=>{this._handleTouchMove_Drag(t),this._isDragging||this._isPinching||this._handleTouchMove(t)}}"
        @touchend="${t=>this._handleTouchEnd(t)}"
      >
        ${this._staticChartContent}
        ${s}
      </svg>
    `}render(){if(!this.hass||!this.config)return j``;const t=this._getLearningData();if(!t)return j`
        <ha-card>
          <div class="card-content">
            <p>${ut(this.hass,"entity_not_found")} ${this.config.learning_entity}</p>
          </div>
        </ha-card>
      `;const e=Math.round(100*t.confidence),i=this._normalizeState(t.state),s="active"===i||"bootstrap"===i,o="disabled"===i,n=ut(this.hass,o?"state_disabled":s?"state_active":"state_off"),a=function(t,e){if(!e)return e;const i=/^([a-z_]+)(.*)$/.exec(e);if(!i)return e;const[,s,o]=i,n=pt(t),a=dt[n]?.[s]??dt.en[s];return a?`${a}${o}`:e}(this.hass,t.status)||ut(this.hass,"waiting"),r=ut(this.hass,s?"stop_learning":"start_learning"),l=s?"mdi:stop":"mdi:play";return j`
      <ha-card>
        <div class="card-content">
          <div class="header-row">
            <div class="header-title">${this.config.name||ut(this.hass,"default_title")}</div>
            
            <div class="controls-container">
              <div class="main-controls">
                ${o?j`
                  <span style="color: var(--secondary-text-color); font-size: 0.9em;">${ut(this.hass,"auto_tpi_disabled")}</span>
                `:j`
                  <mwc-button
                    @click=${()=>this._toggleAutoTpi(s)}
                    class="${s?"stop-btn":"start-btn"}"
                    dense
                    raised
                  >
                    <ha-icon icon="${l}" style="margin-right: 4px;"></ha-icon>
                    ${r}
                  </mwc-button>
                `}
                <ha-icon-button
                   @click="${()=>this._toggleOptions()}"
                   style="margin-left: 0px; color: var(--secondary-text-color);"
                   title="${ut(this.hass,"options")}"
                >
                  <ha-icon icon="${this._showOptions?"mdi:chevron-up":"mdi:chevron-down"}"></ha-icon>
                </ha-icon-button>
              </div>

               ${this._showOptions?j`
                 <div class="options-container">
                 ${s?j`
                  <div class="checkbox-container disabled">
                    <div style="width: 24px; display: flex; justify-content: center; margin-right: 4px;">
                      <ha-checkbox
                        .checked=${t.allowKintBoost}
                        disabled
                        style="pointer-events: none;"
                      ></ha-checkbox>
                    </div>
                    <span class="checkbox-label">${ut(this.hass,"boost_kint")}</span>
                  </div>
                  <div class="checkbox-container disabled">
                    <div style="width: 24px; display: flex; justify-content: center; margin-right: 4px;">
                      <ha-checkbox
                        .checked=${t.allowKextCompensation}
                        disabled
                        style="pointer-events: none;"
                      ></ha-checkbox>
                    </div>
                    <span class="checkbox-label">${ut(this.hass,"unboost_kext")}</span>
                  </div>
                `:j`
                  <div class="checkbox-container" @click="${()=>this._toggleResetCheckbox()}">
                    <div style="width: 24px; display: flex; justify-content: center; margin-right: 4px;">
                      <ha-checkbox
                        .checked=${this._resetChecked}
                        style="pointer-events: none;"
                      ></ha-checkbox>
                    </div>
                    <span class="checkbox-label">${ut(this.hass,"reset")}</span>
                  </div>
                  <div class="checkbox-container" @click="${()=>this._toggleBoostKintCheckbox()}">
                    <div style="width: 24px; display: flex; justify-content: center; margin-right: 4px;">
                      <ha-checkbox
                        .checked=${this._boostKintChecked}
                        style="pointer-events: none;"
                      ></ha-checkbox>
                    </div>
                    <span class="checkbox-label">${ut(this.hass,"boost_kint")}</span>
                  </div>
                   <div class="checkbox-container" @click="${()=>this._toggleUnboostKextCheckbox()}">
                    <div style="width: 24px; display: flex; justify-content: center; margin-right: 4px;">
                      <ha-checkbox
                        .checked=${this._unboostKextChecked}
                        style="pointer-events: none;"
                      ></ha-checkbox>
                    </div>
                    <span class="checkbox-label">${ut(this.hass,"unboost_kext")}</span>
                  </div>
                `}
                </div>
               `:""}
            </div>
          </div>

          <div class="telemetry">
            <div class="telemetry-content">
              <div class="telem-line">
                <span class="label">${ut(this.hass,"state")}</span>
                <span style="${s?"color: var(--success-color, #4CAF50); font-weight: bold;":""}">${n}</span>
                &nbsp;|&nbsp;
                <span class="label">${ut(this.hass,"confidence")}</span> ${e}%
              </div>

              <div class="telem-line" style="align-items: flex-start;">
                <div style="display: flex; flex-direction: column; margin-right: 24px;">
                  <span class="kint-color">Kint: ${t.kint.toFixed(4)}</span>
                  <span style="font-size: 0.9em; opacity: 0.8;">${ut(this.hass,"cycles")} ${t.kintCycles}</span>
                </div>
                <div style="display: flex; flex-direction: column; margin-right: 24px;">
                  <span class="kext-color">Kext: ${t.kext.toFixed(4)}</span>
                  <span style="font-size: 0.9em; opacity: 0.8;">${ut(this.hass,"cycles")} ${t.kextCycles}</span>
                </div>
                <div style="display: flex; flex-direction: column;">
                  <span style="color: var(--chart-color-max-capacity); font-weight: bold;">${ut(this.hass,"heat_rate")}: ${this._getCurrentMaxCapacity()}</span>
                </div>
              </div>

              <div class="telem-line status">
                ${ut(this.hass,"last_cycle")} ${a}
              </div>
            </div>
            
            <div class="zoom-controls">
              <ha-icon-button @click="${()=>this._zoomIn()}">
                <ha-icon icon="mdi:magnify-plus-outline"></ha-icon>
              </ha-icon-button>
              <ha-icon-button @click="${()=>this._resetZoom()}">
                <ha-icon icon="mdi:magnify-remove-outline"></ha-icon>
              </ha-icon-button>
              <ha-icon-button @click="${()=>this._zoomOut()}">
                <ha-icon icon="mdi:magnify-minus-outline"></ha-icon>
              </ha-icon-button>
            </div>
          </div>

            ${this._renderChart()}
            ${this._renderTooltip()}
          </div>
          
          <div class="legend">
            <div class="legend-item clickable" @click="${()=>this._toggleKint()}">
              <span class="dot kint-bg" style="opacity: ${this._showKint?1:.3}"></span> Kint
            </div>
            <div class="legend-item clickable" @click="${()=>this._toggleKext()}">
              <span class="dot kext-bg" style="opacity: ${this._showKext?1:.3}"></span> Kext
            </div>
            <div class="legend-item clickable" @click="${()=>this._toggleMaxCapacity()}">
              <span class="dot max-capacity-bg" style="opacity: ${this._showMaxCapacity?1:.3}"></span> ${ut(this.hass,"legend_hrate")}
            </div>
            <div class="legend-item clickable" @click="${()=>this._toggleSetpoint()}">
              <span class="dot setpoint-bg" style="opacity: ${this._showSetpoint?1:.3}"></span> ${ut(this.hass,"legend_setpoint")}
            </div>
            ${this.config.ext_temp_entity?j`
              <div class="legend-item clickable" @click="${()=>this._toggleExtTemp()}">
                <span class="dot ext-temp-bg" style="opacity: ${this._showExtTemp?1:.3}"></span> ${ut(this.hass,"legend_ext_temp")}
              </div>
            `:""}
            <div class="legend-item clickable" @click="${()=>this._toggleTemp()}">
              <span class="dot temp-bg" style="opacity: ${this._showTemp?1:.3}"></span> ${ut(this.hass,"legend_temp")}
            </div>
            <div class="legend-item clickable" @click="${()=>this._toggleHeating()}">
              <span class="dot heating-bg" style="opacity: ${this._showHeating?1:.3}"></span> ${ut(this.hass,"legend_heat")}
            </div>
          </div>
        </div>
      </ha-card>
    `}static styles=n`
    :host {
      display: block;
      /* Define CSS variables for chart colors */
      --chart-color-kint: #06B6D4;
      --chart-color-kext: rgb(76, 175, 80);
      --chart-color-temp: rgb(33, 150, 243);
      --chart-color-ext-temp: rgb(25, 50, 100);
      --chart-color-setpoint: rgba(255, 152, 0, 0.8);
      --chart-color-setpoint-fill: rgba(255, 152, 0, 0.4);
      --chart-color-heating: rgba(255, 152, 0, 0.7);
      --chart-color-max-capacity: rgb(255, 100, 100);
      --chart-color-grid: #444;
      --chart-color-time-label: #aaa;
      --chart-color-sub-label: #888;
    }
    ha-card {
      background: var(--ha-card-background, var(--card-background-color));
      border-radius: var(--ha-card-border-radius, 12px);
      box-shadow: var(--ha-card-box-shadow);
      color: var(--primary-text-color);
      display: flex;
      flex-direction: column;
    }
    .card-content {
      padding: 16px;
      display: flex;
      flex-direction: column;
      flex: 1;
    }
    .header-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 16px;
    }
    .header-title {
      font-size: 16px;
      font-weight: 500;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: calc(100% - 200px);
      margin-top: 8px;
    }
    .controls-container {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 0px;
    }
    .main-controls {
      display: flex;
      align-items: center;
    }
    .options-container {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      margin-top: 8px;
      margin-right: 8px;
      padding: 8px;
      background: rgba(0, 0, 0, 0.2);
      border-radius: 4px;
      width: 100%;
      box-sizing: border-box;
    }
    .checkbox-container {
      display: flex;
      align-items: center;
      cursor: pointer;
      user-select: none;
      width: 100%;
      margin-bottom: 0;
    }
    .checkbox-container.disabled {
      cursor: default;
      opacity: 0.6;
    }
    .checkbox-label {
      font-size: 12px;
      margin-left: 4px;
    }

    /* Button Colors */
    mwc-button.start-btn {
      --mdc-theme-primary: var(--success-color, #4CAF50);
      --mdc-theme-on-primary: white;
      cursor: pointer;
      padding-left: 10px;
      margin-bottom: -8px;
    }
    mwc-button.stop-btn {
      --mdc-theme-primary: var(--error-color, #F44336);
      --mdc-theme-on-primary: white;
      cursor: pointer;
      padding-left: 10px;
      margin-bottom: -8px;
    }

    .telemetry {
      margin-bottom: 4px; /* Reduced from 16px */
      background: rgba(0,0,0,0.1);
      padding: 8px;
      border-radius: 8px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
    }
    .telemetry-content {
      display: flex;
      flex-direction: column;
    }
    .telem-line {
      font-size: 13px;
      line-height: 1.6;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
    }
    .telem-line.status {
      font-style: italic;
      opacity: 0.7;
      margin-top: 4px;
      font-size: 12px;
      overflow-wrap: anywhere;
      word-break: break-word; /* Deprecated but useful fallback */
      word-break: break-all;  /* Force break for long strings */
      display: block;         /* Ensure block layout for text wrapping */
    }
    .label {
      font-weight: 500;
      opacity: 0.8;
      margin-right: 4px;
    }
    .kint-color { color: var(--chart-color-kint); font-weight: bold; }
    .kext-color { color: var(--chart-color-kext); font-weight: bold; }
    
    .chart-container {
      width: 100%;
      height: 300px;
      position: relative;
      margin-bottom: 0px; /* Reduced from 8px */
      overflow: hidden;
    }
    .zoom-controls {
      display: flex;
      gap: 4px;
    }
    .zoom-controls ha-icon-button {
      --mdc-icon-button-size: 32px;
      --mdc-icon-size: 32px;
    }
    .tooltip {
      position: absolute;
      background: var(--ha-card-background, var(--card-background-color, white));
      color: var(--primary-text-color);
      border: 1px solid var(--divider-color, #ccc);
      padding: 8px 12px;
      border-radius: 4px;
      pointer-events: none;
      font-size: 12px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      z-index: 10;
      white-space: nowrap;
      transition: top 0.1s ease-out, left 0.1s ease-out;
    }
    .loading, .error, .no-data {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      color: var(--secondary-text-color);
      font-size: 12px;
    }
    .error { color: var(--error-color, red); }

    .legend {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 12px;
      font-size: 12px;
      margin-top: -10px;
    }
    .legend-item {
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .clickable { cursor: pointer; user-select: none; }
    .dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; }
    .kint-bg { background: var(--chart-color-kint); }
    .kext-bg { background: var(--chart-color-kext); }
    .temp-bg { background: var(--chart-color-temp); }
    .heating-bg { background: var(--chart-color-heating); }
    .setpoint-bg { background: var(--chart-color-setpoint); }
    .ext-temp-bg { background: var(--chart-color-ext-temp); }
    .max-capacity-bg { background: var(--chart-color-max-capacity); }
  `}customElements.get("auto-tpi-learning-card")||customElements.define("auto-tpi-learning-card",gt);class ft extends lt{static properties={hass:{type:Object},config:{type:Object}};setConfig(t){this.config=t}_findLearningSensor(t){if(!this.hass||!t)return null;const e=t.replace("climate.",""),i=`sensor.${e}_auto_tpi_learning_state`;if(this.hass.states[i])return i;return Object.keys(this.hass.states).find(t=>t.startsWith("sensor.")&&t.includes(e)&&t.endsWith("_auto_tpi_learning_state"))||null}_climateChanged(t){const e=t.detail.value,i={...this.config};i.climate_entity=e;const s=this._findLearningSensor(e);if(s&&(i.learning_entity=s),!i.name&&e){const t=e.replace("climate.","").replace(/_/g," ");i.name=t.charAt(0).toUpperCase()+t.slice(1)}this._fireConfigChanged(i)}_learningChanged(t){const e={...this.config};e.learning_entity=t.detail.value,this._fireConfigChanged(e)}_extTempChanged(t){const e={...this.config};e.ext_temp_entity=t.detail.value,this._fireConfigChanged(e)}_nameChanged(t){const e={...this.config};e.name=t.target.value,this._fireConfigChanged(e)}_fireConfigChanged(t){const e=new CustomEvent("config-changed",{detail:{config:t},bubbles:!0,composed:!0});this.dispatchEvent(e)}_getLearningSensors(){return this.hass?Object.keys(this.hass.states).filter(t=>t.startsWith("sensor.")&&t.endsWith("_auto_tpi_learning_state")):[]}render(){return this.hass&&this.config?j`
      <div class="card-config">
        <div class="option">
          <label>${ut(this.hass,"editor_name")}</label>
          <input 
            type="text" 
            .value="${this.config.name||""}" 
            @input="${this._nameChanged}"
          >
        </div>
        
        <div class="option">
          <label>${ut(this.hass,"editor_climate")}</label>
          <ha-entity-picker
            .hass="${this.hass}"
            .value="${this.config.climate_entity||""}"
            .includeDomains="${["climate"]}"
            @value-changed="${this._climateChanged}"
            allow-custom-entity
          ></ha-entity-picker>
        </div>

        <div class="option">
          <label>${ut(this.hass,"editor_learning")}</label>
          <ha-entity-picker
            .hass="${this.hass}"
            .value="${this.config.learning_entity||""}"
            .includeEntities="${this._getLearningSensors()}"
            @value-changed="${this._learningChanged}"
            allow-custom-entity
          ></ha-entity-picker>
        </div>

        <div class="option">
          <label>${ut(this.hass,"editor_ext_temp")}</label>
          <ha-entity-picker
            .hass="${this.hass}"
            .value="${this.config.ext_temp_entity||""}"
            .includeDomains="${["sensor"]}"
            @value-changed="${this._extTempChanged}"
            allow-custom-entity
          ></ha-entity-picker>
        </div>
      </div>
    `:j``}static styles=n`
    .card-config {
      padding: 16px;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .option {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    label {
      font-size: 12px;
      font-weight: 500;
      color: var(--secondary-text-color);
    }
    input {
      padding: 8px;
      border: 1px solid var(--divider-color, #ccc);
      border-radius: 4px;
      background: var(--card-background-color);
      color: var(--primary-text-color);
      font-size: 14px;
    }
    ha-entity-picker {
      width: 100%;
    }
  `}customElements.get("auto-tpi-learning-card-editor")||customElements.define("auto-tpi-learning-card-editor",ft),window.customCards=window.customCards||[],window.customCards.some(t=>"auto-tpi-learning-card"===t.type)||window.customCards.push({type:"auto-tpi-learning-card",name:"Auto-TPI Learning Card",description:"Visualization of Versatile Thermostat Auto-TPI learning process"});
